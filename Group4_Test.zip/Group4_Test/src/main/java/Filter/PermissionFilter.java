package Filter;

import java.io.IOException;	
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.buf.StringUtils;

import Type.ROLE;

//user.do /member.do /admin.do
public class PermissionFilter implements Filter
{

	Map<String,ROLE> pageGradeMap = new HashMap();	// URL : Permission Value
														// /user.do 	: 0
														// /member.do 	: 1
														// /admin.do 	: 2
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		String projectPath = filterConfig.getServletContext().getContextPath();
	
		pageGradeMap.put(projectPath+"/book/add",ROLE.ROLE_MEMBER);	//1
		

	}
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		//
		System.out.println("[Filter] PermissionFilter..Start");
		
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse resp = (HttpServletResponse)response;

		HttpSession session = req.getSession();
		String myRole = (String)session.getAttribute("role");
		if(myRole==null) {
			resp.sendRedirect(req.getContextPath()+"/login?message=" + URLEncoder.encode("로그인이 필요한 서비스입니다","UTF-8"));
			return ;
		}
		//role값 존재하는 경우
		String url = req.getRequestURI();	// /PJ/user.do , /PJ/member.do , /PJ/admin.do , etc..
		ROLE pageRole =  pageGradeMap.get(url);
		System.out.println("URL : " + url + " pageRole : " + pageRole+ " myRole : " + myRole);
		
		
		ROLE myRoleVal =null;
		if("ROLE_ADMIN".equals(myRole)) {
			myRoleVal = ROLE.ROLE_ADMIN;
		}else if("ROLE_MEMBER".equals(myRole)) {
			myRoleVal = ROLE.ROLE_MEMBER;
		}else if("ROLE_USER".equals(myRole)){
			myRoleVal = ROLE.ROLE_USER;
		}else {
			;
		}
		
		//pageRole<=myRole -> 허용
		if(pageRole.ordinal() > myRoleVal.ordinal()) {
			//pageRole>myRole -> 권한부족(예외페이지로 이동 - Forward / Redirect error.jsp)
			//throw new ServletException("해당 권한으로는 접근이 불가능한 페이지 입니다.");
			resp.sendRedirect(req.getContextPath()+"/error.jsp?message=" + URLEncoder.encode("페이지에 해당 계정 권한이 부족합니다.","UTF-8"));
			return ;
		}
		
		
		chain.doFilter(request, response);

		//
		System.out.println("[Filter] PermissionFilter..End");

	}

}
