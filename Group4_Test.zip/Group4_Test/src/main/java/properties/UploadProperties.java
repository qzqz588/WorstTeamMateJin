package properties;

public class UploadProperties {
	
	public static String uploadPath = "c:\\upload";
	
	public static String profilePath = "profile";
	
	//c:\\upload\\profile\\user계정명\\image.png..
}
