package Type;

public enum ROLE {
	ROLE_USER,		//0
	ROLE_MEMBER,	//1
	ROLE_ADMIN		//2
}
