package Domain.Common.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Domain.Common.Dao.RentalDaoImpl;
import Domain.Common.Dao.ReplyDaoImpl;
import Domain.Common.Dao.ConnectionPool.ConnectionPool;
import Domain.Common.Dto.BookDto;
import Domain.Common.Dto.RentalDto;
import Domain.Common.Dto.UserDto;

public class RentalServiceImpl {
	
	//BookDao 연결
	private RentalDaoImpl rentalDaoImpl;
	
	//ReplyDao 연결
	private ReplyDaoImpl replyDaoImpl;
	
	//UserService 연결
	//private UserServiceImpl userServiceImpl;
	
	//ConnectionPool
	private ConnectionPool connectionPool;
	
	//싱글톤 패턴 처리코드
	private RentalServiceImpl() throws Exception {
		System.out.println("[SERVICE] BookServiceImpl()..");
		rentalDaoImpl = RentalDaoImpl.getInstance();
		replyDaoImpl = ReplyDaoImpl.getInstance();
		//TX
		this.connectionPool = ConnectionPool.getInstance();
		//
		//this.userServiceImpl = userServiceImpl.getInstance();

	};
	private static RentalServiceImpl instance;
	public static RentalServiceImpl getInstance() throws Exception {
		if(instance==null)
			instance = new RentalServiceImpl();
		return instance;
	}
	
	public Map<String,Object> bookRegistration(RentalDto dto) throws Exception{

		Map<String,Object> returnValue = new HashMap();
		int result=0;
		try {
			connectionPool.beginTransaction(); //tx start
					  result = rentalDaoImpl.insert(dto);
					  if(result>0) {
							returnValue.put("success", true);
							returnValue.put("message", "대여!"); 				  
					  }
			connectionPool.commitTransaction(); //tx end
		}catch(Exception e) {
			connectionPool.rollbackTransaction();//
			throw e;
		}
		
		return returnValue;
	}
	//도서내용수정
	
		public boolean rentalUpdate(RentalDto dto, UserDto userDto) throws Exception {
			
			return rentalDaoImpl.update(dto,userDto) > 0;
		}
		//도서삭제
		
		public boolean rentalRemove(long bookCode) throws Exception {
			return rentalDaoImpl.delete(bookCode) > 0;
		}
		
		//도서 조회(단건 - BookDto)
		public RentalDto getBook(long bookCode) throws Exception{
			
			return rentalDaoImpl.select(bookCode);
		}
		
		
		//도서 조회(다건 - List<BookDto))
		public List<RentalDto> getBooks() throws Exception {
			//Tx
			//페이징처리
			//키워드처리
			return rentalDaoImpl.select();
		}


}
