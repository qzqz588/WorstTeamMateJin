package Domain.Common.Dto;

public class RentalDto {
	private long rentalId;
	private long bookCode;
	private String username;
	private String reusername;
	private boolean isReserved;
	


	public long getRentalId() {
		return rentalId;
	}
	public void setRentalId(long rentalId) {
		this.rentalId = rentalId;
	}
	public long getBookCode() {
		return bookCode;
	}
	public void setBookCode(long bookCode) {
		this.bookCode = bookCode;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getReusername() {
		return reusername;
	}
	public void setReusername(String reusername) {
		this.reusername = reusername;
	}
	public boolean getIsReserved() {
		return isReserved;
	}
	public void setIsReserved(boolean isReserved) {
		this.isReserved = isReserved;
	}
	public RentalDto(long rentalId, long bookCode, String username, String reusername, boolean isReserved) {
		super();
		this.rentalId = rentalId;
		this.bookCode = bookCode;
		this.username = username;
		this.reusername = reusername;
		this.isReserved = isReserved;
	}
	@Override
	public String toString() {
		return "RentalDto [rentalId=" + rentalId + ", bookCode=" + bookCode + ", username=" + username + ", reusername="
				+ reusername + ", isReserved=" + isReserved + "]";
	}
	public RentalDto() {
		
	}
	
}
	//디폴트생성자
	//모든인자 생성자
	//getter and setter
	//toString 재정의
	
