/**
 * 
 */
console.log("common.js...");